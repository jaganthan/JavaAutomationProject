package com.computer;

public interface Hardware {
	
	void hardwareResources();

}
