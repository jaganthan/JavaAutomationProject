package com.computer;

public interface Software {
	void softwareResources();
}
