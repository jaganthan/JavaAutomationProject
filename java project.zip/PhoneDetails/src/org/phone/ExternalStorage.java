package org.phone;

public class ExternalStorage {
	
	public void size() {
		// TODO Auto-generated method stub
		System.out.println("1 TB");
	} 
	
	
}
