package org.index;
import java.util.*;

public class NormalForLoop {
	
	public static void main(String[] args) {
		int i;
		List<Integer> q = new ArrayList<Integer>();
		
		q.add(105);
		q.add(205);
		q.add(305);
		q.add(405);
		q.add(505);
		q.add(605);
		q.add(705);
		q.add(805);
		
		for(i=0; i<q; i++)
		{
			System.out.println(i);
		}
		
		
	}

}
