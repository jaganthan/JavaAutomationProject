package org.college;

public class Hostel {

	public void hostelName() {
		// TODO Auto-generated method stub
		
		System.out.println("Hostal Name : Room Lite");
		
	}
	
	
}
