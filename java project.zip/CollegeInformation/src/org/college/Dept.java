package org.college;

public class Dept {

	public void deptName() {
		// TODO Auto-generated method stub
		
		System.out.println("Dept : CSE");
		
	}
	
	
}
