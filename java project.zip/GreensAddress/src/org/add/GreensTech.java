package org.add;

public class GreensTech {
	
	private void greensOmr() {
			
	}
	
	private void greensAdayar() {
	
	}
	
	private void greensThambaram() {
		
	}
	
	private void greensVelachery() {
			
	}
	
	private void greensAnnaNagar() {
		
	}
	
	
	public static void main(String[] args) 
	{
		GreensTech j = new GreensTech();
		
		j.greensOmr();
		j.greensAdayar();
		j.greensThambaram();
		j.greensVelachery();
		j.greensAnnaNagar();
		
		System.out.println("Done");
	}
}
