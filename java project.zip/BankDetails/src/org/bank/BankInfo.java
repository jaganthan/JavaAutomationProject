package org.bank;

public class BankInfo {
	
	public void saving() {

		System.out.println("My Saving is 10%");	
	}
	
	public void fixed() {
		
		System.out.println("Fixed is 5%");
	}
	
	public void deposit() {
		
		System.out.println("Deposit Amount is 15%");
	}
}
