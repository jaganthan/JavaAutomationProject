package org.ifelsestate;

public class Con2 {
	
public static void main(String[] args) {
		

		System.out.println("I Have Only 420rs, Can I Get Wheat, Rice and Water For this Amount?\n");
		
		int Wheat = 150, Rice = 250, Water = 20;
		
		if(Wheat + Rice + Water == 420)
		{
			System.out.println("Yes, you will get");
		}
		
		else
		{
			System.out.println("No, you will not get");
		}
	}
}
