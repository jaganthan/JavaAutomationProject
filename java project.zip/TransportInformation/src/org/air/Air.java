package org.air;

public class Air {

	public void aeroPane() {
		
		System.out.println("    Aeroplane  ");
		System.out.println("\nName : Air India");
		
	}
	
	
}
