package org.familydetails;

public interface FatherDetails  {
	void fatherName();
}
