package org.familydetails;

public interface  MotherDetails {
	
	public abstract void motherInfo();
}
