package org.phone;

public class PhoneInfo {
 
	private void phoneName() {
		// TODO Auto-generated method stub
		System.out.println("Nokia");
	}
	
	private void phoneMieiNum() {
		// TODO Auto-generated method stub
		System.out.println("093210");
	}
	
	private void Camera() {
		// TODO Auto-generated method stub
		System.out.println("64 px");
	}
	private void storage() {
		// TODO Auto-generated method stub
		System.out.println("128 GB");
	}
	
	private void osName() {
		// TODO Auto-generated method stub
		System.out.println("Android");
	}
	
	
	public static void main(String[] args) {
		PhoneInfo p = new PhoneInfo();
		
		p.phoneName();
		p.phoneMieiNum();
		p.storage();
		p.Camera();
		p.osName();
	}
	
	
}

