package com.defalt;

public class Default2 {

	void stdGender()
	{
		System.out.println("Male");
	}
}
