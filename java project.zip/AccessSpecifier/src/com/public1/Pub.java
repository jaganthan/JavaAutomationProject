package com.public1;

public class Pub {
	
public static void main(String[] args) {
	
	Public1 n = new Public1();
	n.stdId();
}
}
