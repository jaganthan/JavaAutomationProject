package com.public1;

public class Extend1 extends Public1 {

	public static void main(String[] args) {
		
	
	Extend1 q = new Extend1();
	q.stdId();
	
	}
	
}
