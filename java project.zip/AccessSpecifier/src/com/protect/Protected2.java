package com.protect;
import com.protect.Protected1;
public class Protected2  {
	
	public static void main(String[] args) {
		
		Protected1 n = new Protected1();
		
		n.stdName();
		
	}
	

}
