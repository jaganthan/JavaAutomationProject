package com.protect;

public class Protected1 {

	protected void stdName() {
	
		System.out.println("Jagan");
	}
	
	public static void main(String[] args) {
		
		Protected1 w = new Protected1();
		
		w.stdName();
		
	}
}
