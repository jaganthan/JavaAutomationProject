package com.protect2;

import com.protect.Protected1;

public class Protected3 extends Protected1{
	
	public static void main(String[] args) {
		
		 Protected3 w = new Protected3();
		 
		 w.stdName();
		
	}
}
