package org.network;

public class Wireless {

	public void modamName() {
		
		System.out.println("Jio");

	}
	
}
