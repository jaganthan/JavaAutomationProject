package org.college;

public class College {
	
	public void collegeName() {
	
		System.out.println("Kings Engineering College");
		
	}
	
	public void collegeCode() {
		
		System.out.println("2108");
	}
	
	public void collegeRank() {
		
		System.out.println("#1");

	}
}
