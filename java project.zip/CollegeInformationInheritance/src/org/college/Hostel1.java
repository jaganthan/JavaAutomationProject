package org.college;

public class Hostel1 extends Dept {
	
	public void HostelName() {
		
		System.out.println("Lookas Hostel");

	}
}
