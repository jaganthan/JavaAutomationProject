package org.abstrat;

public abstract class  Abstract1 {
	
	public abstract void name();
			
	

}
