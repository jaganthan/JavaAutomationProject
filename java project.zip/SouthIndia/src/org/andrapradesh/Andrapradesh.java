package org.andrapradesh;

import org.kerala.Kerala;

public class Andrapradesh extends Kerala{
	
	public void telugu() {
		
		System.out.println("Launguage is : Telugu");

	}
}
