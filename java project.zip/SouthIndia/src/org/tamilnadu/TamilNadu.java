package org.tamilnadu;

public class TamilNadu {
	
	public void tamilLaunguage() {
	
		System.out.println("Launguage is : Tamil");
	}
}
