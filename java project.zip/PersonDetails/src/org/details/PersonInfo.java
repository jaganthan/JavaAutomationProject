package org.details;

public abstract class PersonInfo {
	
	public void personName(){
		
		System.out.println("Name : JAGANATHAN");
	}
	
	public abstract void phNo();
	public abstract void dob();
	public abstract void age();
	public abstract void gender();
}
