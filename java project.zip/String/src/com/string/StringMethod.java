package com.string;

public class StringMethod {

	public static void main(String[] args)
	{
		String s = "GreensTechnology";
		String j = "SeleniumAutomationtool";
		String w = "velmurugan";
		String t = "j a v a p r o g r a m";
		String y = "9095484678";
		System.out.println(s);
		
		int l = s.length();
		System.out.println(l);
		
		int q = j.length();
		System.out.println(q);
		
		int e = w.length();
		System.out.println(e);
		
		int r = t.length();
		System.out.println(r);
		
		int u = y.length();
		System.out.println(u);
		
		int p = s.length() + j.length() + w.length() + t.length() + y.length();
		System.out.println("Sum Of All The Length");
		System.out.println(p);
		
		
	}
}
