package org.all;

import org.english.English;

public class LanguageClass extends English {
	
	public void alllanguage() {
		
		System.out.println("ALL LANGUAGES");

	}
public static void main(String[] args) {
	
	LanguageClass l = new LanguageClass();
	
	l.alllanguage();
	l.englishlanguage();
	l.tamillanguage();
	l.telgulanguage();
}

}
