package org.english;
import org.tamil.Tamil;
public class English extends Tamil {
	
	public void englishlanguage() {

		System.out.println("English");
	}
}
