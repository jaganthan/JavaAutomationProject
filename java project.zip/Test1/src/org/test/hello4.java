package org.test;

public class hello4 {
  public static void main(String[] args) {
    int i=5;
      if (i == 5)
      {
        break;
      }
      System.out.println(i);
  }

}