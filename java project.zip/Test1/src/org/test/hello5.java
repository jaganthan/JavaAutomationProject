package org.test;

public class hello5 {
  public static void main(String[] args) {
    int i=5;
      if (i == 5) {
        continue;
      }
      System.out.println(i);
  }

}