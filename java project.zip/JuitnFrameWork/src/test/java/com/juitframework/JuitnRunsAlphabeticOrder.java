package com.juitframework;

import org.junit.Test;

public class JuitnRunsAlphabeticOrder {
	@Test
	public void a() {
		System.out.println("Test1");
	}
	
	@Test
	public void c() {
		System.out.println("Test3");
	}
	
	@Test
	public void b() {
		System.out.println("Test2");
	}
}
