package SuiteMultiClass;
import org.junit.Test;
public class ClassOne {
	@Test
	public void a()
	{
		System.out.println("Jagan");
	}
}
