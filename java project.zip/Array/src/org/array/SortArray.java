package org.array;

import java.util.Arrays;
public class SortArray {
			
		public static void main(String[] args) {
			
			int r[] = new int[3];
			
			r[0] = 10;
			r[1] = 26;
			r[2] = 15;
			
			//to sort array
			Arrays.sort(r);
			
			//to print sorted array value
			System.out.println(Arrays.toString(r));
			
		}

	}


