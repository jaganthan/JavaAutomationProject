package com.suitmulticlass;
import org.testng.annotations.Test;
public class A {
	@Test
	public void name()
	{
		System.out.println("LOKESHWARI M");
	}
	
	@Test
	public void age()
	{
		System.out.println("21");
	}
	
	@Test
	public void birthday()
	{
		System.out.println("01/09/1999");
	}
	@Test
	public void qualification()
	{
		System.out.println("B.E");
	}
}
