package com.suitmulticlass;

public class MainCLass {
	
}
