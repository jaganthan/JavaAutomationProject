package com.suitmulticlass;

import org.testng.annotations.Test;

public class B {
	@Test
	public void name()
	{
		System.out.println("JOTHILAKSHMI M");
	}
	
	@Test
	public void age()
	{
		System.out.println("48");
	}
	@Test
	public void birthday()
	{
		System.out.println("19/04/1973");
	}
	@Test
	public void qualification()
	{
		System.out.println("Home-Care");
	}
}
