package org.we;

public abstract class Ab1
{
	public abstract void ug();
	
	
}