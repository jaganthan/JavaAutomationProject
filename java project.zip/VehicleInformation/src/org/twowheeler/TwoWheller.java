package org.twowheeler;


public class TwoWheller {

	public void bike() {
		
		System.out.println("Bike Name : R15 V3");
		
	}
	
	public void cycle() {
		
		System.out.println("Cycle Name : Herculas");

	}
	
	
}
