package org.threewheeler;

public class ThreeWheeler {
	
	public void auto() {
		
		System.out.println("Three Wheeler : Auto");
		
	}
	
		
}
