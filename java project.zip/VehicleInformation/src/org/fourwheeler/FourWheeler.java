package org.fourwheeler;

public class FourWheeler {

	public void car() {
			
		System.out.println("Four Wheeler : Car");
		
		}
		
	public void bus() {
			
		System.out.println("Four Wheeler : Bus");
		
		}
		
	public void lorry() {
			
		
		System.out.println("Four Wheeler : Lorry");
		
		}
		
			
}
